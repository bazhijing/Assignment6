-- MySQL dump 10.13  Distrib 5.7.9, for osx10.9 (x86_64)
--
-- Host: localhost    Database: java
-- ------------------------------------------------------
-- Server version	5.7.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `2014302580178_petdex`
--

DROP TABLE IF EXISTS `2014302580178_petdex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `2014302580178_petdex` (
  `id` mediumint(8) unsigned NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `egname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `money` mediumint(5) unsigned NOT NULL,
  `txt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xs` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xs2` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hp` smallint(6) NOT NULL DEFAULT '0',
  `atk` smallint(6) NOT NULL DEFAULT '0',
  `def` smallint(6) NOT NULL DEFAULT '0',
  `spatk` smallint(6) NOT NULL DEFAULT '0',
  `spdef` smallint(6) NOT NULL DEFAULT '0',
  `speed` smallint(6) NOT NULL DEFAULT '0',
  `uplv` smallint(5) unsigned NOT NULL DEFAULT '0',
  `upto` mediumint(8) unsigned DEFAULT NULL,
  `buy` tinyint(2) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2014302580178_petdex`
--
