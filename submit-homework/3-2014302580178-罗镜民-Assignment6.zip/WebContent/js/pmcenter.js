jQuery(document).ready(function() {
	jQuery("#reg_btn").click(function() {
		jQuery("#login").hide(2000);
		jQuery("#register").fadeIn(2000);

	});
	jQuery("#log_btn").click(function() {
		jQuery("#register").hide(2000);
		jQuery("#login").fadeIn(2000);
	});
	jQuery("#log_quit").click(function() {
		jQuery("#login").hide(1000);
	});
	jQuery("#reg_quit").click(function() {
		jQuery("#register").hide(1000);
	});
	jQuery("#myname_btn").mouseover(function() {
		jQuery("#myinf").slideDown({
			queue : false,
			duration : 800,
			easing : 'easeOutBounce'
		});
	});
	jQuery("#myname_btn").mouseleave(function() {
		setTimeout(function() {
			
			jQuery("#myinf").slideUp({
				queue : false,
				duration : 800,
				easing : 'easeOutBounce'
			});
			
		}, 2000)

	});
	

});
function logswitch() {
	var check = document.getElementById("ustom-switch-03");
	if (check.checked == true) {
		document.getElementById("ustom-switch-03").value = "1";
	} else {
		document.getElementById("ustom-switch-03").value = "0";
	}
}