package ming.pets;

import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class person {
	private pmcenter_db mysql=null;
	public boolean connect() throws InterruptedException{
		 mysql = new pmcenter_db();
		 int i=0;
		 while(!mysql.isConnected && i<=10){
			 mysql.connect();
			 Thread.sleep(500);
		 }
		 return mysql.isConnected;
	}
	public String[] get_person_inf(String username){
		String person_inf[] = new String[5];
		String sql = "select * from 2014302580178_member where username='"+username+"' limit 1";
		PreparedStatement sttm;
		
			try {
				sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
				mysql.rs = sttm.executeQuery(sql);
				while(mysql.rs.next()){
					person_inf[0] = mysql.rs.getString(1);
					person_inf[1] = mysql.rs.getString(4);
					person_inf[2] = mysql.rs.getString(5);
					person_inf[3] = mysql.rs.getString(6);
					person_inf[4] = mysql.rs.getString(7);
					
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
				person_inf[0]=" ";
			
			}
		return person_inf;
	}
	
}
