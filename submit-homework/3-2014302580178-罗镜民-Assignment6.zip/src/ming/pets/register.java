package ming.pets;

import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class register {
	private pmcenter_db mysql = null;

	public boolean connect() throws InterruptedException {
		mysql = new pmcenter_db();
		int i = 0;
		while (!mysql.isConnected && i <= 10) {
			mysql.connect();
			Thread.sleep(500);
		}
		return mysql.isConnected;
	}

	public boolean is_exist(String username) {
		String sql = "select * from 2014302580178_member where username='" + username + "'";
		PreparedStatement sttm;

		try {
			sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
			mysql.rs = sttm.executeQuery(sql);
			while (mysql.rs.next()) {
				
				return true;
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			return true;
		}
		return false;
	}

	public boolean reg(String username,String password, String email){
		PreparedStatement sttm;
		String sql="INSERT INTO 2014302580178_member (username,password,mail,money,usergroup,isAct) VALUES (?,?,?,?,?,?)";
			try {
				sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
			
				sttm.setString(1, username);
				sttm.setString(2, password);
				sttm.setString(3, email);
				sttm.setString(4, "1000");
				sttm.setString(5, "1");
				sttm.setString(6, "0");
				
				sttm.executeUpdate();
				return true;
			} catch (SQLException e) {
				
				e.printStackTrace();
				return false;
			}
	
}}
