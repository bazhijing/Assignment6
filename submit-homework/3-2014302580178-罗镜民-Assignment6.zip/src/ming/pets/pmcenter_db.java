package ming.pets;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;

public class pmcenter_db {
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	public boolean isConnected = false;
	public java.sql.Connection con = null;
	public ResultSet rs;
	public boolean connect() {
		try {
			// 加载MySql的驱动类
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("aaa");
			return false;
		}
		try {
			con = DriverManager.getConnection(this.url);
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
		
		this.isConnected = true;
		return true;
	}

	public pmcenter_db(String url) {

		this.isConnected = connect();
	}

	public pmcenter_db() {
		this.isConnected = connect();
	}

	/**
	 * @author Ming
	 * @param db mysql查询语句
	 * @return 返回执行是否成功，通过这个尽量避免网页崩溃
	 */
	
	boolean updata() {
		return false;
	}

	public boolean dis_connect() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		this.isConnected = false;
		return true;
	}

}