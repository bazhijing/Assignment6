package ming.pets;

import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class shop {
	private pmcenter_db mysql = null;

	public boolean connect() throws InterruptedException {
		mysql = new pmcenter_db();
		int i = 0;
		while (!mysql.isConnected && i <= 10) {
			mysql.connect();
			Thread.sleep(500);
		}
		return mysql.isConnected;
	}

	public int listpet(String[][] pets) {
		String sql = "select * from 2014302580178_petdex where buy='1'";
		PreparedStatement sttm;
		int i = 0;
		try {
			sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
			mysql.rs = sttm.executeQuery(sql);
			while (mysql.rs.next()) {
				pets[i][0] = mysql.rs.getString(1);// pid
				pets[i][1] = mysql.rs.getString(2);// name
				pets[i][2] = mysql.rs.getString(4);// money
				i++;

			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return i;
	}

	public boolean buy(String uid, String pid, int prize) {
		//prize获得动态原理相近
		String money_sql = "select * from 2014302580178_member where uid=" + uid;
		PreparedStatement sttm;
		int money = 0;
		try {
			sttm = (PreparedStatement) mysql.con.prepareStatement(money_sql);
			mysql.rs = sttm.executeQuery(money_sql);
			
			if (mysql.rs.next())
				money = Integer.valueOf(mysql.rs.getString(5)).intValue();
			if (money < prize) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		String now =  String.valueOf(money-prize);
		String kill_money = "UPDATE 2014302580178_member set money='"+now+"' where uid="+uid;
		try {
			sttm = (PreparedStatement) mysql.con.prepareStatement(kill_money);
			int i = sttm.executeUpdate(kill_money);

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		String sql = "select * from 2014302580178_pets where uid=" + uid + " and pos=1";
		String insert_sql = "";
		boolean haspm  = false;
		try {
			sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
			mysql.rs = sttm.executeQuery(sql);
			haspm = mysql.rs.next();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		try {
				insert_sql = "INSERT INTO 2014302580178_pets (uid,pid,pos) VALUES (?,?,?)";
				sttm = (PreparedStatement) mysql.con.prepareStatement(insert_sql);
				sttm.setString(1, uid);
				sttm.setString(2, pid);
				System.out.println(uid);
				System.out.println(pid);
			if (haspm) {
				
				
				sttm.setString(3, "2");
				sttm.executeUpdate();
			} else {
				
				sttm.setString(3, "1");
				sttm.executeUpdate();
			}
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
}
