package ming.pets;

import java.sql.SQLException;
import java.sql.ResultSet;
import com.mysql.jdbc.PreparedStatement;

public class login {
	private pmcenter_db mysql=null;
	public boolean connect() throws InterruptedException{
		 mysql = new pmcenter_db();
		 int i=0;
		 while(!mysql.isConnected && i<=10){
			 mysql.connect();
			 Thread.sleep(500);
		 }
		 return mysql.isConnected;
	}
	public  boolean loginnow(String username, String password){
		String sql = "select * from 2014302580178_member where username='"+username+"'";
		PreparedStatement sttm;
		
			try {
				sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
				mysql.rs = sttm.executeQuery(sql);
				String true_password="";
				while(mysql.rs.next()){
					true_password = mysql.rs.getString(3);
				}
			
				if(true_password.equals(password))return true;
				else{
					return false;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
	}
}
