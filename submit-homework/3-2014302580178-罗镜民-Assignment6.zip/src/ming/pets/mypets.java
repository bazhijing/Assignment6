package ming.pets;

import java.sql.SQLException;

import org.omg.CORBA.PERSIST_STORE;

import com.mysql.jdbc.PreparedStatement;

public class mypets {
	private pmcenter_db mysql = null;

	public boolean connect() throws InterruptedException {
		mysql = new pmcenter_db();
		int i = 0;
		while (!mysql.isConnected && i <= 10) {
			mysql.connect();
			Thread.sleep(500);
		}
		return mysql.isConnected;
	}

	public int pets(String uid, String pets[][]) {
		String sql = "select * from 2014302580178_pets where uid='" + uid + "' and pos=1 ";
		String sql2 = "select * from 2014302580178_pets where uid='" + uid + "' and pos=2 limit 5";
		PreparedStatement sttm;
		int i = 0;
		try {
			sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
			mysql.rs = sttm.executeQuery(sql);
			while (mysql.rs.next()) {

				pets[i][0] = mysql.rs.getString(1);// id
				pets[i][1] = mysql.rs.getString(3);// pet id (493)
				pets[i][2] = mysql.rs.getString(4);// name
				pets[i][3] = mysql.rs.getString(5);// level
				pets[i][4] = mysql.rs.getString(6);// exps
				pets[i][5] = mysql.rs.getString(7);// pos
				i++;

			}
			sttm = (PreparedStatement) mysql.con.prepareStatement(sql2);
			mysql.rs = sttm.executeQuery(sql2);
			while (mysql.rs.next()) {

				pets[i][0] = mysql.rs.getString(1);// id
				pets[i][1] = mysql.rs.getString(3);// pet id (493)
				pets[i][2] = mysql.rs.getString(4);// name
				pets[i][3] = mysql.rs.getString(5);// level
				pets[i][4] = mysql.rs.getString(6);// exps
				pets[i][5] = mysql.rs.getString(7);// pos
				i++;

			}

		} catch (SQLException e) {
			e.printStackTrace();
			// 实际再进行处理
			i = -1;

		}
		return i;

	}

	public void pet_detail(String[] first_pet, String id) {
		String sql = "select * from 2014302580178_petdex where id='" + id+"'";
		PreparedStatement sttm;
		try {
			sttm = (PreparedStatement) mysql.con.prepareStatement(sql);
			mysql.rs = sttm.executeQuery(sql);
			while (mysql.rs.next()) {
				first_pet[0] = mysql.rs.getString(2);// true_name
				first_pet[1] = mysql.rs.getString(3);// eg_name
				first_pet[2] = mysql.rs.getString(5);// txt
				first_pet[3] = mysql.rs.getString(6);// xs1
				first_pet[4] = mysql.rs.getString(7);// xs2
				first_pet[5] = mysql.rs.getString(8);// zz1
				first_pet[6] = mysql.rs.getString(9);// zz2
				first_pet[7] = mysql.rs.getString(10);// zz3
				first_pet[8] = mysql.rs.getString(11);// zz4
				first_pet[9] = mysql.rs.getString(12);// zz5
				first_pet[10] = mysql.rs.getString(13);// zz6
				
				
								
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}

	}

	public void close() {
		mysql.dis_connect();
	}

}
